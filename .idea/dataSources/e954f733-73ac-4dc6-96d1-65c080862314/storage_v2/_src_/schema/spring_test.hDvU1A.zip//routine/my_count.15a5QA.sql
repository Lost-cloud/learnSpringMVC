CREATE PROCEDURE my_count(IN  query_role_name VARCHAR(60), IN start_row INT, IN end_row INT, OUT role VARCHAR(60),
                          OUT total_num       INT, OUT cur_date TIMESTAMP, OUT information VARCHAR(60))
  begin
	declare ref_cursor cursor for select id from (select * from test.role_table rt 
		where role_name like concat('%',query_role_name,'%') and id<=end_row) as a where id>=start_row;
    
	if  instr(query_role_name,'king')!=0 then
		set role='king';
	end if;
    
    select count(*) into total_num from role_table where role_name like concat('%',query_role_name,'%');
    select current_time() into cur_date;
    
    open ref_cursor;
    fetch ref_cursor into information;
    close ref_cursor;
    
end;

